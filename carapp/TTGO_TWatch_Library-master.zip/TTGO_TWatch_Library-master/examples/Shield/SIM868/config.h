
// => Hardware select
// #define LILYGO_WATCH_2019_WITH_TOUCH
//#define LILYGO_WATCH_2019_NO_TOUCH



//NOT SUPPORT ...
//#define LILYGO_WATCH_BLOCK
// #define LILYGO_WATCH_2020_V1
//NOT SUPPORT ...


// => Function select
#define LILYGO_WATCH_HAS_MOTOR       //To use MOTOR, you need to enable the macro MOTOR
#define LILYGO_WATCH_HAS_SIM868      //To use SIM868, you need to enable the macro SIM868
#define LILYGO_WATCH_HAS_SDCARD

#include <LilyGoWatch.h>