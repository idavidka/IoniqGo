// => Hardware select
#define LILYGO_WATCH_2019_WITH_TOUCH         // To use T-Watch2019 with touchscreen, please uncomment this line
// #define LILYGO_WATCH_2019_NO_TOUCH           // To use T-Watch2019 Not touchscreen , please uncomment this line
// #define LILYGO_WATCH_BLOCK

//No SUPPORT!!!!
//#define LILYGO_LILYPI_V1
//#define LILYGO_WATCH_2020_V1
//No SUPPORT!!!!
#define LILYGO_WATCH_DRV2605

#include <LilyGoWatch.h>


